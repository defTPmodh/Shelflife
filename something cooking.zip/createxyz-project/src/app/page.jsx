"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [activeTab, setActiveTab] = useState("home");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showPlansModal, setShowPlansModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loginForm, setLoginForm] = useState({
    email: "",
    password: "",
  });
  const [registerForm, setRegisterForm] = useState({
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [subscriptionTier, setSubscriptionTier] = useState("free");
  const categories = ["All", "Dairy", "Fruits", "Vegetables", "Meat", "Pantry"];
  const [newProduct, setNewProduct] = useState({
    name: "",
    expiry: "",
    quantity: 1,
    location: "pantry",
    category: "Pantry",
  });
  const [editingProduct, setEditingProduct] = useState(null);
  const [products, setProducts] = useState([
    {
      id: 1,
      name: "Milk",
      expiry: "2024-03-10",
      quantity: 1,
      category: "Dairy",
      status: "near",
    },
    {
      id: 2,
      name: "Bread",
      expiry: "2024-03-12",
      quantity: 2,
      category: "Pantry",
      status: "near",
    },
    {
      id: 3,
      name: "Apples",
      expiry: "2024-03-13",
      quantity: 6,
      category: "Fruits",
      status: "near",
    },
  ]);
  const [error, setError] = useState(null);
  const [upload, { loading }] = useUpload();
  const [barcodeScannerActive, setBarcodeScannerActive] = useState(false);
  const [recipes] = useState([
    {
      id: 1,
      name: "Butter Chicken",
      time: "45 min",
      ingredients: [
        "Chicken",
        "Yogurt",
        "Tomatoes",
        "Butter",
        "Cream",
        "Garam Masala",
      ],
      image: "butter-chicken.jpg",
    },
    {
      id: 2,
      name: "Vegetable Biryani",
      time: "60 min",
      ingredients: [
        "Basmati Rice",
        "Mixed Vegetables",
        "Biryani Masala",
        "Saffron",
        "Ghee",
        "Onions",
      ],
      image: "biryani.jpg",
    },
    {
      id: 3,
      name: "Palak Paneer",
      time: "30 min",
      ingredients: [
        "Spinach",
        "Paneer",
        "Onions",
        "Tomatoes",
        "Ginger",
        "Garlic",
      ],
      image: "palak-paneer.jpg",
    },
    {
      id: 4,
      name: "Dal Makhani",
      time: "45 min",
      ingredients: [
        "Black Lentils",
        "Kidney Beans",
        "Cream",
        "Butter",
        "Tomatoes",
        "Spices",
      ],
      image: "dal-makhani.jpg",
    },
    {
      id: 5,
      name: "Chicken Tikka Masala",
      time: "50 min",
      ingredients: [
        "Chicken",
        "Yogurt",
        "Tikka Masala",
        "Cream",
        "Onions",
        "Tomatoes",
      ],
      image: "tikka-masala.jpg",
    },
    {
      id: 6,
      name: "Aloo Gobi",
      time: "35 min",
      ingredients: [
        "Potatoes",
        "Cauliflower",
        "Onions",
        "Tomatoes",
        "Turmeric",
        "Cumin",
      ],
      image: "aloo-gobi.jpg",
    },
  ]);
  const [settings, setSettings] = useState({
    notifications: true,
    smartHome: false,
    darkMode: false,
  });
  const calculateDaysUntilExpiry = (expiryDate) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };
  const handleLogin = (e) => {
    e.preventDefault();
    setIsLoggedIn(true);
    setShowLoginModal(false);
  };
  const handleLogout = () => {
    setIsLoggedIn(false);
    setSubscriptionTier("free");
    setActiveTab("home");
  };
  const handleRegister = (e) => {
    e.preventDefault();
    if (registerForm.password !== registerForm.confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    setShowRegisterModal(false);
    setShowPlansModal(true);
  };
  const getStatusColor = (status) => {
    switch (status) {
      case "fresh":
        return "bg-green-500";
      case "near":
        return "bg-yellow-500";
      case "expired":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };
  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.expiry) return;

    if (products.length >= 30 && subscriptionTier === "free") {
      setError("Upgrade to premium to add more than 30 products");
      return;
    }

    const today = new Date();
    const expiryDate = new Date(newProduct.expiry);
    let status = "fresh";

    if (expiryDate < today) {
      status = "expired";
    } else if ((expiryDate - today) / (1000 * 60 * 60 * 24) < 7) {
      status = "near";
    }

    if (editingProduct) {
      setProducts(
        products.map((p) =>
          p.id === editingProduct.id ? { ...p, ...newProduct, status } : p
        )
      );
      setEditingProduct(null);
    } else {
      setProducts((prevProducts) => {
        const newProducts = [
          ...prevProducts,
          {
            id: prevProducts.length + 1,
            ...newProduct,
            status,
          },
        ];
        return newProducts.sort(
          (a, b) => new Date(a.expiry) - new Date(b.expiry)
        );
      });
    }

    setNewProduct({
      name: "",
      expiry: "",
      quantity: 1,
      location: "pantry",
      category: "Pantry",
    });
    setShowAddModal(false);
  };
  const toggleSetting = (setting) => {
    setSettings((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }));
  };
  const handleBarcodeDetected = async (barcode) => {
    const mockProductData = {
      name: "Scanned Item",
      expiry: "2024-03-01",
      quantity: 1,
      location: "pantry",
      category: "Pantry",
    };
    setNewProduct(mockProductData);
    setShowAddModal(true);
    setBarcodeScannerActive(false);
  };
  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (selectedCategory === "All" || product.category === selectedCategory)
  );
  const productStats = categories.reduce((acc, category) => {
    if (category !== "All") {
      acc[category] = products.filter((p) => p.category === category).length;
    }
    return acc;
  }, {});
  const handleSelectPlan = (plan) => {
    setSubscriptionTier(plan);
    setIsLoggedIn(true);
    setShowPlansModal(false);
  };
  const handleRemoveProduct = (id) => {
    setProducts(products.filter((product) => product.id !== id));
  };
  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setNewProduct({
      name: product.name,
      expiry: product.expiry,
      quantity: product.quantity,
      category: product.category,
      location: product.location || "pantry",
    });
    setShowAddModal(true);
  };

  return (
    <>
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      />
      <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

      <div
        className={`min-h-screen ${
          settings.darkMode ? "bg-gray-900" : "bg-gray-100"
        } transition-colors duration-300`}
      >
        <div
          className={`max-w-md mx-auto ${
            settings.darkMode ? "bg-gray-800" : "bg-white"
          } min-h-screen flex flex-col shadow-2xl transition-colors duration-300`}
        >
          <header
            className={`${
              settings.darkMode ? "bg-gray-800" : "bg-[#4A90E2]"
            } text-white p-4 flex items-center justify-between`}
          >
            <h1 className="text-xl font-roboto font-bold">ShelfLife</h1>
            {!isLoggedIn ? (
              <div className="space-x-2">
                <button
                  onClick={() => setShowRegisterModal(true)}
                  className={`px-4 py-2 ${
                    settings.darkMode
                      ? "bg-gray-700 text-white"
                      : "bg-white text-[#4A90E2]"
                  } rounded`}
                >
                  Register
                </button>
                <button
                  onClick={() => setShowLoginModal(true)}
                  className={`px-4 py-2 ${
                    settings.darkMode
                      ? "bg-gray-700 text-white"
                      : "bg-white text-[#4A90E2] border border-[#4A90E2]"
                  } rounded`}
                >
                  Login
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <button className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                  <i className="fas fa-bell"></i>
                </button>
                <button
                  onClick={handleLogout}
                  className={`px-4 py-2 ${
                    settings.darkMode
                      ? "bg-gray-700 text-white"
                      : "bg-white text-[#4A90E2] border border-[#4A90E2]"
                  } rounded`}
                >
                  Logout
                </button>
              </div>
            )}
          </header>

          {showAddModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded-lg w-80">
                <h3 className="font-bold mb-4">
                  {editingProduct ? "Edit Product" : "Add New Product"}
                </h3>
                <div className="space-y-4">
                  <input
                    type="text"
                    name="name"
                    placeholder="Product Name"
                    className="w-full p-2 border rounded"
                    value={newProduct.name}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, name: e.target.value })
                    }
                  />

                  <select
                    name="category"
                    className="w-full p-2 border rounded"
                    value={newProduct.category}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, category: e.target.value })
                    }
                  >
                    {categories.slice(1).map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>

                  <input
                    type="date"
                    name="expiry"
                    className="w-full p-2 border rounded"
                    value={newProduct.expiry}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, expiry: e.target.value })
                    }
                  />

                  <input
                    type="number"
                    name="quantity"
                    placeholder="Quantity"
                    min="1"
                    className="w-full p-2 border rounded"
                    value={newProduct.quantity}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        quantity: parseInt(e.target.value),
                      })
                    }
                  />

                  <select
                    name="location"
                    className="w-full p-2 border rounded"
                    value={newProduct.location}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, location: e.target.value })
                    }
                  >
                    <option value="pantry">Pantry</option>
                    <option value="fridge">Fridge</option>
                    <option value="freezer">Freezer</option>
                  </select>

                  <div className="flex justify-between">
                    <button
                      onClick={() => {
                        setShowAddModal(false);
                        setEditingProduct(null);
                        setNewProduct({
                          name: "",
                          expiry: "",
                          quantity: 1,
                          location: "pantry",
                          category: "Pantry",
                        });
                      }}
                      className="px-4 py-2"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleAddProduct}
                      className="px-4 py-2 bg-[#4A90E2] text-white rounded"
                    >
                      {editingProduct ? "Update" : "Add"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {showLoginModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded-lg w-80">
                <h3 className="font-bold mb-4">Login to ShelfLife</h3>
                <form onSubmit={handleLogin} className="space-y-4">
                  <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    className="w-full p-2 border rounded"
                    value={loginForm.email}
                    onChange={(e) =>
                      setLoginForm({ ...loginForm, email: e.target.value })
                    }
                  />
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      name="password"
                      placeholder="Password"
                      className="w-full p-2 border rounded"
                      value={loginForm.password}
                      onChange={(e) =>
                        setLoginForm({ ...loginForm, password: e.target.value })
                      }
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2 top-2 text-gray-500"
                    >
                      <i
                        className={`fas ${
                          showPassword ? "fa-eye-slash" : "fa-eye"
                        }`}
                      ></i>
                    </button>
                  </div>
                  <div className="flex justify-between">
                    <button
                      type="button"
                      onClick={() => setShowLoginModal(false)}
                      className="px-4 py-2"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                    >
                      Login
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {showRegisterModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded-lg w-80">
                <h3 className="font-bold mb-4">Register for ShelfLife</h3>
                <form onSubmit={handleRegister} className="space-y-4">
                  <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    className="w-full p-2 border rounded"
                    value={registerForm.email}
                    onChange={(e) =>
                      setRegisterForm({
                        ...registerForm,
                        email: e.target.value,
                      })
                    }
                  />
                  <input
                    type="password"
                    name="password"
                    placeholder="Password"
                    className="w-full p-2 border rounded"
                    value={registerForm.password}
                    onChange={(e) =>
                      setRegisterForm({
                        ...registerForm,
                        password: e.target.value,
                      })
                    }
                  />
                  <input
                    type="password"
                    name="confirmPassword"
                    placeholder="Confirm Password"
                    className="w-full p-2 border rounded"
                    value={registerForm.confirmPassword}
                    onChange={(e) =>
                      setRegisterForm({
                        ...registerForm,
                        confirmPassword: e.target.value,
                      })
                    }
                  />
                  {error && <div className="text-red-500 text-sm">{error}</div>}
                  <div className="flex justify-between">
                    <button
                      type="button"
                      onClick={() => {
                        setShowRegisterModal(false);
                        setError(null);
                      }}
                      className="px-4 py-2"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-[#4A90E2] text-white rounded"
                    >
                      Register
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {showPlansModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded-lg w-96">
                <h3 className="font-bold mb-6 text-center text-xl">
                  Choose Your Plan
                </h3>
                <div className="space-y-4">
                  <div
                    className="border rounded-lg p-4 hover:border-blue-500 cursor-pointer"
                    onClick={() => handleSelectPlan("free")}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-semibold text-lg">Basic Plan</h4>
                      <span className="text-green-600 font-bold">Free</span>
                    </div>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Up to 30 products
                      </li>
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Basic expiry tracking
                      </li>
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Manual product entry
                      </li>
                    </ul>
                  </div>
                  <div
                    className="border-2 border-blue-500 rounded-lg p-4 hover:bg-blue-50 cursor-pointer relative overflow-hidden"
                    onClick={() => handleSelectPlan("premium")}
                  >
                    <div className="absolute -right-8 -top-8 bg-blue-500 text-white px-8 py-1 rotate-45">
                      Best Value
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-semibold text-lg">Premium Plan</h4>
                      <span className="text-green-600 font-bold">4.99/mo</span>
                    </div>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Unlimited products
                      </li>
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Smart Things Integration
                      </li>
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Barcode scanning
                      </li>
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Advanced analytics
                      </li>
                      <li className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        Priority support
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-auto">
            {activeTab === "home" && (
              <div
                className="p-4 space-y-4"
                style={{ animation: "slideIn 0.3s ease-out" }}
              >
                {!isLoggedIn && (
                  <div
                    className={`${
                      settings.darkMode
                        ? "bg-gray-700 border-gray-600"
                        : "bg-blue-50 border-blue-200"
                    } p-4 rounded-lg border transform hover:scale-105 transition-transform duration-200`}
                  >
                    <h2 className="font-roboto font-bold mb-2 text-white"></h2>
                    <p
                      className={`text-sm ${
                        settings.darkMode ? "text-gray-300" : "text-gray-600"
                      } mb-2`}
                    >
                      Welcome To ShelfLife
                    </p>
                    <div className="space-x-2">
                      <button
                        onClick={() => setShowRegisterModal(true)}
                        className={`${
                          settings.darkMode
                            ? "bg-gray-600 hover:bg-gray-500"
                            : "bg-[#4A90E2] hover:bg-[#357ABD]"
                        } text-white px-4 py-2 rounded transition-colors duration-200`}
                      >
                        Register
                      </button>
                      <button
                        onClick={() => setShowLoginModal(true)}
                        className={`${
                          settings.darkMode
                            ? "bg-gray-800 hover:bg-gray-700 border-gray-600"
                            : "bg-[#4A90E2] hover:bg-[#357ABD]"
                        } text-white px-4 py-2 rounded transition-colors duration-200`}
                      >
                        Login
                      </button>
                    </div>
                  </div>
                )}

                <div
                  className={`${
                    settings.darkMode
                      ? "bg-gray-700 border-gray-600"
                      : "bg-yellow-50 border-yellow-200"
                  } p-4 rounded-lg border transform hover:scale-105 transition-transform duration-200`}
                  style={{ animation: "fadeIn 0.5s ease-out" }}
                >
                  <h2 className="font-roboto font-bold mb-2 text-white">
                    Expiring Soon
                  </h2>
                  <div className="space-y-2">
                    {products
                      .filter((p) => p.status === "near")
                      .map((product, index) => (
                        <div
                          key={product.id}
                          className={`flex items-center justify-between ${
                            settings.darkMode ? "bg-gray-800" : "bg-white"
                          } p-2 rounded hover:shadow-md transition-shadow duration-200`}
                          style={{
                            animation: `slideIn ${0.2 + index * 0.1}s ease-out`,
                          }}
                        >
                          <span
                            className={settings.darkMode ? "text-white" : ""}
                          >
                            {product.name}
                          </span>
                          <span
                            className={`text-sm ${
                              settings.darkMode
                                ? "text-gray-400"
                                : "text-gray-500"
                            }`}
                          >
                            {calculateDaysUntilExpiry(product.expiry)} days left
                          </span>
                        </div>
                      ))}
                  </div>
                </div>

                {isLoggedIn && (
                  <div
                    className={`${
                      settings.darkMode ? "bg-gray-700" : "bg-white"
                    } p-4 rounded-lg border ${
                      settings.darkMode ? "border-gray-600" : ""
                    } transform hover:scale-105 transition-transform duration-200`}
                    style={{ animation: "fadeIn 0.7s ease-out" }}
                  >
                    <h2
                      className={`font-roboto font-bold mb-4 ${
                        settings.darkMode ? "text-white" : "text-gray-800"
                      }`}
                    >
                      Product Categories
                    </h2>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      {categories.slice(1).map((category, index) => (
                        <div
                          key={category}
                          className={`${
                            settings.darkMode ? "bg-gray-800" : "bg-gray-50"
                          } p-4 rounded-lg hover:shadow-lg transition-shadow duration-200`}
                          style={{
                            animation: `slideIn ${0.3 + index * 0.1}s ease-out`,
                          }}
                        >
                          <div className="flex justify-between items-center mb-2">
                            <span
                              className={`font-medium ${
                                settings.darkMode
                                  ? "text-white"
                                  : "text-gray-800"
                              }`}
                            >
                              {category}
                            </span>
                            <span
                              className={`text-sm ${
                                settings.darkMode
                                  ? "text-gray-400"
                                  : "text-gray-600"
                              }`}
                            >
                              {productStats[category]} items
                            </span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded overflow-hidden">
                            <div
                              className="h-full bg-[#4A90E2] rounded transition-all duration-500 ease-out"
                              style={{
                                width: `${
                                  (productStats[category] / products.length) *
                                  100
                                }%`,
                              }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <canvas id="categoryChart"></canvas>
                    <script>{`
                      const ctx = document.getElementById('categoryChart');
                      new Chart(ctx, {
                        type: 'pie',
                        data: {
                          labels: ${JSON.stringify(Object.keys(productStats))},
                          datasets: [{
                            data: ${JSON.stringify(
                              Object.values(productStats)
                            )},
                            backgroundColor: [
                              '#4A90E2',
                              '#357ABD',
                              '#2B6298',
                              '#214B73',
                              '#17344E'
                            ]
                          }]
                        },
                        options: {
                          animation: {
                            animateRotate: true,
                            animateScale: true
                          },
                          plugins: {
                            legend: {
                              position: 'bottom',
                              labels: {
                                color: '${
                                  settings.darkMode ? "white" : "black"
                                }',
                                padding: 20
                              }
                            }
                          }
                        }
                      });
                    `}</script>
                  </div>
                )}

                <div
                  className="grid grid-cols-2 gap-4"
                  style={{ animation: "slideIn 0.9s ease-out" }}
                >
                  <button
                    onClick={() => setActiveTab("scan")}
                    className={`${
                      settings.darkMode
                        ? "bg-gray-700 hover:bg-gray-600"
                        : "bg-[#4A90E2] hover:bg-[#357ABD]"
                    } text-white p-6 rounded-xl flex flex-col items-center transform hover:scale-105 transition-all duration-200`}
                  >
                    <i className="fas fa-barcode text-2xl mb-2"></i>
                    <span>Scan Product</span>
                  </button>
                  <button
                    onClick={() => setActiveTab("inventory")}
                    className={`${
                      settings.darkMode
                        ? "bg-gray-700 hover:bg-gray-600"
                        : "bg-[#4A90E2] hover:bg-[#357ABD]"
                    } text-white p-6 rounded-xl flex flex-col items-center transform hover:scale-105 transition-all duration-200`}
                  >
                    <i className="fas fa-box-open text-2xl mb-2"></i>
                    <span>Inventory</span>
                  </button>
                  <button
                    onClick={() => setActiveTab("recipes")}
                    className={`${
                      settings.darkMode
                        ? "bg-gray-700 hover:bg-gray-600"
                        : "bg-[#4A90E2] hover:bg-[#357ABD]"
                    } text-white p-6 rounded-xl flex flex-col items-center transform hover:scale-105 transition-all duration-200`}
                  >
                    <i className="fas fa-utensils text-2xl mb-2"></i>
                    <span>Recipes</span>
                  </button>
                  <button
                    onClick={() => setActiveTab("settings")}
                    className={`${
                      settings.darkMode
                        ? "bg-gray-700 hover:bg-gray-600"
                        : "bg-[#4A90E2] hover:bg-[#357ABD]"
                    } text-white p-6 rounded-xl flex flex-col items-center transform hover:scale-105 transition-all duration-200`}
                  >
                    <i className="fas fa-cog text-2xl mb-2"></i>
                    <span>Settings</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === "scan" && (
              <div className="p-4 text-center">
                {!isLoggedIn || subscriptionTier === "free" ? (
                  <div className="bg-purple-50 p-6 rounded-lg">
                    <i className="fas fa-lock text-4xl text-purple-600 mb-4"></i>
                    <h3 className="font-bold mb-2">Premium Feature</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Upgrade to Premium to unlock barcode scanning
                    </p>
                    <button
                      onClick={() => setShowPlansModal(true)}
                      className="bg-purple-600 text-white px-6 py-2 rounded-lg"
                    >
                      Upgrade Now
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 mb-4">
                      {barcodeScannerActive ? (
                        <div className="relative">
                          <video
                            id="scanner"
                            className="w-full h-64 object-cover"
                          ></video>
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-48 h-1 bg-red-500 animate-pulse"></div>
                          </div>
                        </div>
                      ) : (
                        <>
                          <i className="fas fa-camera text-4xl text-gray-400 mb-2"></i>
                          <p>Point camera at barcode</p>
                        </>
                      )}
                    </div>
                    <button
                      onClick={() =>
                        setBarcodeScannerActive(!barcodeScannerActive)
                      }
                      className="bg-[#4A90E2] text-white px-6 py-2 rounded-lg"
                    >
                      {barcodeScannerActive
                        ? "Stop Scanning"
                        : "Start Scanning"}
                    </button>
                  </>
                )}
              </div>
            )}

            {activeTab === "inventory" && (
              <div className="p-4">
                <div className="mb-4 flex space-x-2">
                  <input
                    type="text"
                    placeholder="Search products..."
                    className="flex-1 p-2 border rounded"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  <select
                    className="p-2 border rounded"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  {filteredProducts.map((product) => (
                    <div
                      key={product.id}
                      className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm"
                    >
                      <div className="flex items-center">
                        {product.category === "Dairy" && (
                          <i className="fas fa-cheese text-yellow-500 mr-2"></i>
                        )}
                        <div>
                          <h3 className="font-semibold">{product.name}</h3>
                          <p className="text-sm text-gray-500">
                            {calculateDaysUntilExpiry(product.expiry)} days
                            until expiry
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-3 h-3 rounded-full ${getStatusColor(
                            product.status
                          )}`}
                        ></div>
                        <button
                          onClick={() => handleEditProduct(product)}
                          className="text-blue-500 hover:text-blue-700"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button
                          onClick={() => handleRemoveProduct(product.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setShowAddModal(true)}
                  className="fixed bottom-20 right-4 w-14 h-14 bg-[#4A90E2] text-white rounded-full shadow-lg flex items-center justify-center"
                >
                  <i className="fas fa-plus text-xl"></i>
                </button>
              </div>
            )}

            {activeTab === "settings" && (
              <div className="p-4">
                <div className="bg-white rounded-lg p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">Notifications</h3>
                      <p className="text-sm text-gray-500">
                        Get alerts for expiring items
                      </p>
                    </div>
                    <button
                      onClick={() => toggleSetting("notifications")}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        settings.notifications ? "bg-green-500" : "bg-gray-300"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 bg-white rounded-full transform transition-transform ${
                          settings.notifications
                            ? "translate-x-6"
                            : "translate-x-1"
                        }`}
                      ></div>
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">Smart Home Integration</h3>
                      <p className="text-sm text-gray-500">
                        Connect with smart fridges
                      </p>
                      {subscriptionTier === "free" && (
                        <span className="text-xs text-purple-600">
                          ✨ Premium Feature
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        if (subscriptionTier === "premium") {
                          toggleSetting("smartHome");
                        } else {
                          setShowPlansModal(true);
                        }
                      }}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        settings.smartHome ? "bg-green-500" : "bg-gray-300"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 bg-white rounded-full transform transition-transform ${
                          settings.smartHome ? "translate-x-6" : "translate-x-1"
                        }`}
                      ></div>
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">Dark Mode</h3>
                      <p className="text-sm text-gray-500">
                        Toggle dark color scheme
                      </p>
                    </div>
                    <button
                      onClick={() => toggleSetting("darkMode")}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        settings.darkMode ? "bg-green-500" : "bg-gray-300"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 bg-white rounded-full transform transition-transform ${
                          settings.darkMode ? "translate-x-6" : "translate-x-1"
                        }`}
                      ></div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "recipes" && (
              <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                {recipes.map((recipe) => (
                  <div
                    key={recipe.id}
                    className={`${
                      settings.darkMode ? "bg-gray-700" : "bg-white"
                    } rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-200`}
                  >
                    <img
                      src={recipe.image}
                      alt={`${recipe.name} recipe`}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-4">
                      <h3
                        className={`font-bold text-lg mb-2 ${
                          settings.darkMode ? "text-white" : "text-gray-800"
                        }`}
                      >
                        {recipe.name}
                      </h3>
                      <p
                        className={`text-sm mb-3 ${
                          settings.darkMode ? "text-gray-300" : "text-gray-600"
                        }`}
                      >
                        <i className="fas fa-clock mr-2"></i>
                        {recipe.time}
                      </p>
                      <div className="space-y-2">
                        <h4
                          className={`font-semibold ${
                            settings.darkMode
                              ? "text-gray-300"
                              : "text-gray-700"
                          }`}
                        >
                          Ingredients:
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {recipe.ingredients.map((ingredient, index) => (
                            <span
                              key={index}
                              className={`text-xs px-2 py-1 rounded ${
                                settings.darkMode
                                  ? "bg-gray-600 text-gray-300"
                                  : "bg-gray-100 text-gray-700"
                              }`}
                            >
                              {ingredient}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <nav
            className={`flex border-t ${
              settings.darkMode ? "bg-gray-800 border-gray-700" : "bg-white"
            }`}
          >
            <button
              onClick={() => setActiveTab("home")}
              className={`flex-1 p-4 flex flex-col items-center ${
                activeTab === "home"
                  ? settings.darkMode
                    ? "text-[#9B59B6]"
                    : "text-[#2ECC71]"
                  : settings.darkMode
                  ? "text-gray-400"
                  : "text-gray-500"
              }`}
            >
              <i className="fas fa-home text-xl mb-1"></i>
              <span className="text-xs">Home</span>
            </button>
            <button
              onClick={() => setActiveTab("scan")}
              className={`flex-1 p-4 flex flex-col items-center ${
                activeTab === "scan"
                  ? settings.darkMode
                    ? "text-[#9B59B6]"
                    : "text-[#2ECC71]"
                  : settings.darkMode
                  ? "text-gray-400"
                  : "text-gray-500"
              }`}
            >
              <i className="fas fa-barcode text-xl mb-1"></i>
              <span className="text-xs">Scan</span>
            </button>
            <button
              onClick={() => setActiveTab("inventory")}
              className={`flex-1 p-4 flex flex-col items-center ${
                activeTab === "inventory"
                  ? settings.darkMode
                    ? "text-[#9B59B6]"
                    : "text-[#2ECC71]"
                  : settings.darkMode
                  ? "text-gray-400"
                  : "text-gray-500"
              }`}
            >
              <i className="fas fa-box-open text-xl mb-1"></i>
              <span className="text-xs">Items</span>
            </button>
            <button
              onClick={() => setActiveTab("settings")}
              className={`flex-1 p-4 flex flex-col items-center ${
                activeTab === "settings"
                  ? settings.darkMode
                    ? "text-[#9B59B6]"
                    : "text-[#2ECC71]"
                  : settings.darkMode
                  ? "text-gray-400"
                  : "text-gray-500"
              }`}
            >
              <i className="fas fa-cog text-xl mb-1"></i>
              <span className="text-xs">Settings</span>
            </button>
          </nav>
        </div>
      </div>
      <style jsx global>{`
        @keyframes slideIn {
          from {
            transform: translateY(20px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        @keyframes pulse {
          0% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
          100% {
            transform: scale(1);
          }
        }
      `}</style>
    </>
  );
}

export default MainComponent;